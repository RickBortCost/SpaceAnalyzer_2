# Space Analyzer V1.25.0 — sorgenti aggiornati

Implementazione basata sui sorgenti V1.24.0 dell’handoff, senza ricreare l’applicazione.

- Acquisizione simultanea OPC UA, ADS, MQTT e S7 in ogni sottoinsieme.
- Registrazioni miste CSV, Parquet, FDA/DAS4, RBF, DAT/PDA3 e DAT/iba, con i limiti reali dei codec e delle DLL.
- Sessioni indipendenti, configurazione persistente, cataloghi, controlli e cinque lingue.

Leggere `source/GUIDA_ACQUISIZIONE_SIMULTANEA.md`, `source/CHANGELOG.txt` e `VERIFICHE_V1.25.0.md` prima dell’uso.

## Esecuzione dai sorgenti

Creare un virtualenv, installare `source/requirements.txt`, quindi eseguire `python app.py` dalla directory `source/`. Le dipendenze di test sono descritte nel rapporto.

## Windows

Questa consegna contiene sorgenti e verifiche, non un nuovo EXE Windows. Su un PC con Python e Go compatibili eseguire `source/build_windows.cmd`; la procedura può richiedere accesso ai runtime/dipendenze. Il build verifica che il payload corrisponda ai sorgenti. Validare l’eseguibile e i collegamenti reali prima dell’uso operativo.

I componenti nativi e il modello PDA3 già presenti nell’handoff mantengono le rispettive licenze e limitazioni. Non viene fornita una licenza iba. I certificati client privati non sono distribuiti; vengono generati localmente. I certificati server e la fiducia vanno configurati per l’installazione destinataria.

`MANIFEST_SHA256.json` descrive tutti i file di questa consegna, escluso il manifest stesso. `examples/` contiene esempi originali dell’handoff, non acquisizioni nuove della V1.25. I risultati delle nuove esecuzioni sono esclusivamente in `evidence_v1.25/`.
