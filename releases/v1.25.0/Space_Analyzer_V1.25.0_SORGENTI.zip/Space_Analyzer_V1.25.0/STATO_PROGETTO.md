# Stato della consegna V1.25.0

La richiesta multi-protocollo è implementata nei sorgenti: gestione indipendente delle quattro sorgenti e registrazione mista nei sei formati esistenti. La vecchia limitazione CSV/Parquet è rimossa insieme alle modifiche di codec, metadati, finalizzazione e rilettura necessarie. PDA3 usa una politica esplicita di proiezione a 10 ms e conserva gli originali.

Risultati e limiti sono in VERIFICHE_V1.25.0.md. Restano da eseguire nell’ambiente destinatario: build/esecuzione Windows, PLC reali, DLL ADS reale, ibaFiles.dll con licenza reale, validazione nelle applicazioni native e controllo visivo browser. Non trattare i test simulati come certificazione di tali componenti.
