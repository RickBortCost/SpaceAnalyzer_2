/* Observed MQTT catalogue and scalar measurements never modify acquisition. */
(()=>{
  let autoscan=false,catalogBusy=false,catalogRevision='',catalogTicket=0,lastCatalog=null;
  let quickBusy=false,lastOptions='',lastResult=null,preferredSignal='';
  const folders=new Map();
  window.mqttBrowseActive=()=>currentSource()==='mqtt';
  const mqttReady=()=>window.sourceSessionsStatus?.mqtt?window.sourceSessionsStatus.mqtt.state==='connected':currentSource()==='mqtt'&&connected;
  const write=(el,text)=>{if(el.textContent!==String(text))el.textContent=String(text);};
  function treeSync(data){
    const host=$('tree');
    if(!host.dataset.mqttTree){host.replaceChildren();host.dataset.mqttTree='true';folders.clear();}
    const byTopic=new Map();
    for(const node of data.nodes){const topic=node.nodeid.slice(5).split('#')[0];if(!byTopic.has(topic))byTopic.set(topic,[]);byTopic.get(topic).push(node);}
    for(const root of data.roots){
      let f=folders.get(root.nodeid);
      if(!f){
        const wrap=document.createElement('div'),row=document.createElement('div'),exp=document.createElement('button'),name=document.createElement('span'),children=document.createElement('div');
        row.className='node';exp.className='expander';exp.textContent='›';exp.setAttribute('aria-expanded','false');name.className='name';name.textContent=root.display_name.split('/').filter(Boolean).at(-1)||root.display_name;name.title=root.display_name+' · '+root.nodeid;exp.setAttribute('aria-label',root.display_name);children.className='indent';children.hidden=true;
        row.append(exp,name);wrap.append(row,children);host.append(wrap);f={wrap,children,exp,leaves:new Map()};folders.set(root.nodeid,f);
        exp.onclick=()=>{children.hidden=!children.hidden;exp.textContent=children.hidden?'›':'⌄';exp.setAttribute('aria-expanded',String(!children.hidden));};
      }
      for(const node of byTopic.get(root.display_name)||[]){
        let row=f.leaves.get(node.nodeid);
        if(!row){row=document.createElement('div');row.className='node';row.dataset.nodeid=node.nodeid;const name=document.createElement('span');name.className='name';row.append(selectionBox(node),name);f.children.append(row);f.leaves.set(node.nodeid,row);}
        write(row.querySelector('.name'),treeLabel(node));row.title=node.nodeid;const cb=row.querySelector('input');cb.checked=selected.has(node.nodeid);cb.disabled=!!recordState.busy;
      }
    }
  }
  window.refreshMqttCatalog=async function(tree=null){
    if(catalogBusy)return;
    const ticket=catalogTicket;catalogBusy=true;
    try{
      const data=await request('/api/mqtt/catalog?revision='+encodeURIComponent(catalogRevision));
      if(ticket!==catalogTicket||!mqttBrowseActive())return;
      if(!data.unchanged){catalogRevision=data.revision;lastCatalog=data;scanNodes=data.nodes;renderScan();treeSync(data);}
      else if(lastCatalog&&!$('tree').dataset.mqttTree){treeSync(lastCatalog);}
      if(tree!==null)setView(tree?'tree':'list');
      $('scan-progress').value=1;write($('result-count'),String(scanNodes.length));
      I18N.bind($('scan-status'),'textContent',()=>I18N.t('Catalogo MQTT aggiornato'),true);
    }catch(e){if(tree!==null)throw e;/* Keep the last visible tree during reconnect. */}
    finally{catalogBusy=false;}
  };
  window.refreshLiveExtras=()=>{
    const active=mqttBrowseActive();$('mqtt-autoscan').hidden=!active;$('mqtt-autoscan').disabled=!mqttReady();
    $('mqtt-autoscan').setAttribute('aria-pressed',String(autoscan));$('mqtt-autoscan').classList.toggle('active',autoscan);
    const sessions=window.sourceSessionsStatus||{};
    $('parallel-status').hidden=!Object.keys(sessions).length;
    write($('parallel-status'),Object.entries(sessions).map(([p,s])=>p.toUpperCase()+': '+I18N.t(s.state==='connected'?'Connesso':s.state==='reconnecting'?'Riconnessione…':'Non connesso')+(s.error?' · '+s.error:'')).join(' · '));

  };
  $('mqtt-autoscan').onclick=()=>{autoscan=!autoscan;refreshLiveExtras();if(autoscan)refreshMqttCatalog().catch(()=>{});};
  $('mqtt-parallel').onchange=()=>{
    if($('mqtt-parallel').checked)$('mqtt_time_basis').value='arrival';
    sourcePresentation();scheduleWorkspaceSave();
  };
  $('browse-source').onchange=()=>{
    catalogTicket++;catalogRevision='';lastCatalog=null;folders.clear();
    switchSource($('browse-source').value).then(()=>{refreshLiveExtras();if(mqttBrowseActive()&&mqttReady())refreshMqttCatalog(true).catch(e=>notice(e.message,true));}).catch(e=>notice(e.message,true));
  };
  // Explicit disconnect/source changes invalidate in-flight catalogue responses.
  $('disconnect').addEventListener('click',()=>{autoscan=false;catalogTicket++;catalogRevision='';refreshLiveExtras();});
  $('data-source').addEventListener('change',()=>{autoscan=false;catalogTicket++;catalogRevision='';lastCatalog=null;delete $('tree').dataset.mqttTree;});
  $('connect').addEventListener('click',()=>{catalogTicket++;catalogRevision='';lastCatalog=null;});
  function renderQuick(){
    const result=lastResult,metric=$('quick-operation').value,k=$('quick-factor').value===''?NaN:Number($('quick-factor').value),offset=$('quick-offset').value===''?NaN:Number($('quick-offset').value);
    const raw=result?.statistics?.[metric],value=Number.isFinite(raw)&&Number.isFinite(k)&&Number.isFinite(offset)?raw*k+offset:null;
    write($('quick-value'),Number.isFinite(value)?valueText(value):'—');
  }
  for(const id of ['quick-operation','quick-factor','quick-offset'])$(id).addEventListener('input',renderQuick);
  $('quick-signal').onchange=()=>{preferredSignal=$('quick-signal').value;lastResult=null;renderQuick();quickTick();};
  async function quickTick(){
    if(quickBusy||applicationClosed||$('live-page').hidden)return;
    const nodes=liveCharts.active?.trend.nodes||new Map();
    const options=JSON.stringify([...nodes].map(([id,n])=>[id,n.display_name]));
    if(options!==lastOptions){const old=preferredSignal||$('quick-signal').value;$('quick-signal').replaceChildren(...[...nodes].map(([id,n])=>new Option(n.display_name||id,id)));if(nodes.has(old))$('quick-signal').value=old;lastOptions=options;}
    const chosen=$('quick-signal').value;
    if(!chosen){lastResult=null;renderQuick();write($('quick-range'),'');return;}
    quickBusy=true;
    let requestGraph=null;
    try{
      for(const graph of liveCharts.charts){
        requestGraph=graph;
        const active=graph===liveCharts.active,show=active&&$('quick-calculations').open,t=graph.trend;
        const marked=Number.isFinite(t.markers.x1)&&Number.isFinite(t.markers.x2)&&t.markers.x1!==t.markers.x2;
        if(!show&&!(marked&&graph.element.querySelector('.marker-analysis')?.open))continue;
        const range=marked?{...t.markers}:{x1:t.domain?.xmin,x2:t.domain?.xmax};
        if(!Number.isFinite(range.x1)||!Number.isFinite(range.x2)||range.x1===range.x2){if(show){lastResult=null;renderQuick();write($('quick-range'),I18N.t('Nessun campione nella vista congelata'));}continue;}
        const ids=[...new Set([...(marked?graph.ids:[]),...(show?[chosen]:[])])].slice(0,64);
        if(!ids.length)continue;
        const body={source:'live',signal_ids:ids,...range};
        const frozen=t.frozen,revision=graph.analysisSnapshotRevision;
        if(frozen){await graph.analysisSnapshotPromise;if(!graph.analysisSnapshotId)throw Error(I18N.t('Riprendi Play e metti nuovamente in Pausa'));body.snapshot_id=graph.analysisSnapshotId;}
        const result=await request('/api/analysis/quick',body);
        if(frozen!==t.frozen||revision!==graph.analysisSnapshotRevision||!liveCharts.charts.includes(graph))continue;
        if(marked){
          t.exactMarkerMode=true;t.exactMarkerTimes=range;
          t.exactMarkerRows=new Map(result.results.map(r=>{
            const cfg=graph.signalSettings?.[r.nodeid]||{},gain=Number.isFinite(cfg.gain)?cfg.gain:1,offset=Number.isFinite(cfg.offset)?cfg.offset:0;
            return [r.nodeid,{...r,x1:r.x1?{...r.x1,value:r.x1.value*gain+offset}:null,x2:r.x2?{...r.x2,value:r.x2.value*gain+offset}:null}];
          }));t.updateMarkerTable();
        }
        if(show&&chosen===$('quick-signal').value&&graph===liveCharts.active){
          lastResult=result.results.find(r=>r.nodeid===chosen);renderQuick();
          write($('quick-range'),I18N.t(marked?'Intervallo marker':'Finestra visibile')+' · '+new Date(range.x1).toLocaleTimeString(I18N.locale())+' → '+new Date(range.x2).toLocaleTimeString(I18N.locale())+' · '+(lastResult?.count||0)+' '+I18N.t('campioni validi')+' · '+(lastResult?.excluded||0)+' '+I18N.t('esclusi')+' · '+I18N.t('Valori originali: risultato × K + offset'));
        }
      }
    }catch(e){
      if(requestGraph){const t=requestGraph.trend;t.exactMarkerRows=new Map();t.exactMarkerTimes={...t.markers};t.updateMarkerTable();}
      lastResult=null;renderQuick();write($('quick-range'),e.message);
    }
    finally{quickBusy=false;}
  }
  const timer=setInterval(()=>{if(applicationClosed){clearInterval(timer);return;}refreshLiveExtras();if(autoscan&&mqttBrowseActive()&&mqttReady()&&!document.hidden)refreshMqttCatalog().catch(()=>{});quickTick();},1000);
  window.quickCalculationsTick=quickTick;
  const capture=window.captureStudio,restore=window.restoreStudio;
  window.captureStudio=()=>({...capture(),quick:{signal:$('quick-signal').value,operation:$('quick-operation').value,factor:$('quick-factor').value,offset:$('quick-offset').value,open:$('quick-calculations').open}});
  window.restoreStudio=saved=>{restore(saved);if(saved.quick){preferredSignal=String(saved.quick.signal||'');for(const key of ['operation','factor','offset'])if(saved.quick[key]!==undefined)$('quick-'+key).value=saved.quick[key];$('quick-calculations').open=saved.quick.open!==false;}};
  window.addEventListener('space-analyzer-languagechange',()=>{lastOptions='';renderQuick();});
  refreshLiveExtras();
})();
