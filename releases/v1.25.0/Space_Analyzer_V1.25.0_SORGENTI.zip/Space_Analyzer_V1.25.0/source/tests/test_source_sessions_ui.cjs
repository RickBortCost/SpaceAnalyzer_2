// DOM/component test of the real HTML and JS against a running local test service.
// Canvas calls are stubbed: this test does not claim pixel rendering or native Windows QA.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {JSDOM, VirtualConsole} = require(process.env.JSDOM_PATH || 'jsdom');
const [base, endpoint, rootNode, ...ids] = process.argv.slice(2);
const errors = [];const pages=[];
const wait = async (condition, label, timeout=12000) => {
  const end=Date.now()+timeout;
  while(Date.now()<end){if(await condition()){console.error('PASS '+label);return;}await new Promise(r=>setTimeout(r,35));}
  throw new Error('Timeout: '+label+'; errors: '+errors.join('; '));
};
const api = async route => (await fetch(base+route)).json();

async function page(){
  const html=await (await fetch(base)).text();
  const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
  const dom=new JSDOM(html,{url:base,runScripts:'outside-only',pretendToBeVisual:true,virtualConsole:vc});
  pages.push(dom);const w=dom.window;w.FormData=globalThis.FormData;
  w.AbortController=globalThis.AbortController;
  w.fetch=async(url,options)=>{try{return await fetch(new URL(url,base),options);}catch(e){errors.push('fetch '+url+': '+e.message);throw e;}};
  w.ResizeObserver=class{observe(){} disconnect(){}};
  w.HTMLCanvasElement.prototype.getBoundingClientRect=()=>({x:0,y:0,left:0,top:0,width:950,height:560,right:950,bottom:560});
  const ctx=new Proxy({measureText:text=>({width:String(text).length*7})},{get:(obj,key)=>key in obj?obj[key]:(()=>{})});
  w.HTMLCanvasElement.prototype.getContext=()=>ctx;
  w.addEventListener('error',e=>errors.push(e.message));
  w.eval(['i18n-catalog.js','i18n.js','trend.js','workspace.js','app.js','history.js','advanced.js','fft-ui.js','source.js','s7.js','calculations.js','studio.js','ssh.js','live-extras.js'].map(file=>fs.readFileSync(path.join(__dirname,'../static',file),'utf8')).join('\n')+'\nwindow.uiTest={get trend(){return liveCharts.charts[0].trend},get selected(){return selected},get record(){return recordState},get connected(){return connected},get liveCharts(){return liveCharts},get historyCharts(){return historyCharts},selectHistoryFile,loadHistory,importHistoryLocalFile,openSignalProperties,openAxisProperties,duplicateStudioChart,setNavigatorRange,dropHistorySignal,switchSource,saveWorkspace,chartSnapshot,config,stopPolling(){polling=false;clearTimeout(pollTimer);clearTimeout(workspaceTimer);}};');
  const $=id=>w.document.getElementById(id);
  try{await wait(()=>$('endpoint').value,'configuration loaded');}catch(e){console.error('UI notice:', $('msg').textContent);throw e;}
  await w.opcuaConfigReady;return {dom,w,$,t:w.uiTest};
}

(async()=>{
 const {w,$,t}=await page(),checks=[],cfg=JSON.parse(process.env.TEST_MULTI_CONFIG),signals=JSON.parse(process.env.TEST_MULTI_SIGNALS);
 try{
  for(const p of ['opcua','ads','mqtt','s7']){$('enable-'+p).checked=true;$('period-'+p).value=cfg.source_intervals[p];}
  $('mqtt-parallel').checked=true;$('mqtt-parallel').dispatchEvent(new w.Event('change'));
  $('endpoint').value=cfg.endpoint;$('security').value='None';$('sample_ms').value='20';
  $('ads_tcp_port').value=cfg.ads_tcp_port;$('s7_host').value=cfg.s7_host;$('s7_tcp_port').value=cfg.s7_tcp_port;
  $('mqtt_host').value='127.0.0.1';$('mqtt_port').value=cfg.mqtt_port;$('mqtt_topics').value='plant/#';
  w.s7Tags=cfg.s7_tags;
  $('connect').click();
  await wait(async()=>{const j=await api('/api/values');return Object.values(j.sources||{}).length===4&&Object.values(j.sources).every(s=>s.state==='connected');},'four independent UI sessions');
  for(const p of ['opcua','ads','mqtt','s7']){
   await t.switchSource(p);
   $('manual-node').value=signals[p];$('add-node').click();
   await wait(()=>t.selected.has(signals[p]),'add '+p+' signal without clearing previous selections');
  }
  await wait(async()=>{const j=await api('/api/values');return Object.values(signals).every(n=>j.samples[n]?.length>3);},'four displayed sources');
  const selection=[...t.selected.keys()],epoch=(await api('/api/values')).diagnostics.session_samples;
  $('disconnect-ads').click();
  await wait(async()=>(await api('/api/values')).sources.ads.state==='disconnected','individual ADS disconnect');
  assert.deepEqual([...t.selected.keys()],selection);
  $('reconnect-ads').click();
  await wait(async()=>(await api('/api/values')).sources.ads.state==='connected','individual ADS reconnect');
  checks.push('Configure four protocols, switch catalogs, select four signals, disconnect and reconnect ADS while retaining the common chart');
  await t.switchSource('mqtt');
  await w.refreshMqttCatalog(true);
  const exp=$('tree').querySelector('.expander');exp.click();
  const box=$('tree').querySelector('input[data-nodeid="'+signals.mqtt+'"]');box.focus();$('tree').scrollTop=15;
  $('mqtt-autoscan').click();const count=$('tree').querySelectorAll('input').length;
  await wait(()=>$('tree').querySelectorAll('input').length>count,'incremental MQTT discovery',7000);
  assert.equal($('tree').querySelector('input[data-nodeid="'+signals.mqtt+'"]'),box);
  assert.equal(w.document.activeElement,box);assert.equal($('tree').scrollTop,15);assert.equal(exp.getAttribute('aria-expanded'),'true');
  checks.push('MQTT Autoscan preserves expanded branches, focus, scroll and selection during four-source acquisition');
  for(const [language,label] of [['en','Reconnect source'],['de','Quelle neu verbinden'],['fr','Reconnecter la source'],['es','Reconectar fuente'],['it','Riconnetti sorgente']]){
   await w.I18N.setLanguage(language,{persist:true});assert.equal($('reconnect-ads').textContent,label);
  }
  checks.push('New controls translated in five languages');
  assert.equal($('record-form').querySelectorAll('input[name="record-format"]').length,6);
  assert([...$('record-form').querySelectorAll('input[name="record-format"]')].every(el=>!el.disabled));
  await t.saveWorkspace(true);
  const saved=await api('/api/config');assert.equal(saved.enabled_sources.length,4);
  checks.push('All six format choices remain available and multi-source configuration persists');
  $('disconnect').click();await wait(async()=>!Object.keys((await api('/api/values')).sources||{}).length,'all sessions closed');
  assert.equal(errors.length,0,errors.join('; '));console.log(JSON.stringify({result:'PASS',checks,files:[]}));
 }finally{t.stopPolling();for(const d of pages)d.window.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
