"""Scalar interval measurements on original samples, without derived signals."""
import math


def summarize(rows, ids, start, end, x1, x2):
    groups={n:[] for n in ids}
    for row in rows:
        nid=row['node_id']
        if nid in groups and start<=row['timestamp_ms']<=end:
            groups[nid].append(row)
    results=[]
    def valid(row):
        v=row.get('value_numeric')
        return row.get('quality','Good')=='Good' and isinstance(v,(int,float)) and math.isfinite(v)
    def point(rows,t):
        if not rows:return None
        r=min(rows,key=lambda r:abs(r['timestamp_ms']-t))
        return {'timestamp_ms':r['timestamp_ms'],'value':r['value_numeric']} if valid(r) else None
    def finite(v):return v if v is not None and math.isfinite(v) else None
    for nid,points in groups.items():
        points.sort(key=lambda r:r['timestamp_ms'])
        good=[r for r in points if valid(r)];values=[float(r['value_numeric']) for r in good]
        stats={};a=point(points,x1);b=point(points,x2)
        if values:
            scale=max(map(abs,values)) or 1
            scaled=[v/scale for v in values]
            mean=math.fsum(scaled)/len(values)
            integral=0.;duration=0.
            for left,right in zip(points,points[1:]):
                dt=(right['timestamp_ms']-left['timestamp_ms'])/1000
                limit=3*max(float(left.get('sample_ms') or 0),float(right.get('sample_ms') or 0))/1000
                if valid(left) and valid(right) and 0<dt<=limit:
                    integral+=(left['value_numeric']/2+right['value_numeric']/2)*dt;duration+=dt
            delta=b['value']-a['value'] if a and b else None
            stats=dict(last=values[-1],min=min(values),max=max(values),mean=mean*scale,
                rms=math.sqrt(math.fsum(v*v for v in scaled)/len(values))*scale,
                std=math.sqrt(math.fsum((v-mean)**2 for v in scaled)/len(values))*scale,
                p2p=max(values)-min(values),delta=delta,
                slope=delta/((x2-x1)/1000) if delta is not None and x2!=x1 else None,
                integral=integral if duration else None)
        results.append(dict(nodeid=nid,x1=a,x2=b,count=len(values),excluded=len(points)-len(values),
                            statistics={k:finite(v) for k,v in stats.items()}))
    return results
