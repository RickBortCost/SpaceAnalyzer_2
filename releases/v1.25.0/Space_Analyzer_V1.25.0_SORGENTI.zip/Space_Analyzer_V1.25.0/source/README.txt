SPACE ANALYZER V1.24.0 WINDOWS x64

Estrarre tutto lo ZIP e avviare Space_Analyzer_V1.24.0.exe.
Chiudere la versione precedente prima di avviare questa.
Runtime e dipendenze sono inclusi; non serve installare Python.

Novità: Autoscan MQTT ogni secondo senza ricostruire i nodi;
marker relativi alla schermata durante Play; FFT in Pausa con X1/X2;
acquisizione simultanea OPC UA + MQTT; riquadro Dati calcolati sotto i grafici.
Guida operativa: GUIDA_LIVE_V1.24.txt.
Le cinque lingue e le funzioni della V1.23.0 sono incluse.

Verifiche: 39 test backend e 8 flussi DOM/componenti UI superati.
Protocolli verificati con server OPC UA e peer MQTT locali.
Nessuna esecuzione nativa Windows o prova con PLC/broker di campo.
Sorgenti completi, documentazione e report inclusi.
