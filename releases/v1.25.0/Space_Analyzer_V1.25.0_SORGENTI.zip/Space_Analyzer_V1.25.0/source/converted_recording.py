"""Shared lifecycle: original acquisition first, compatibility export after Stop."""
import logging
import threading
import time
from pathlib import Path


class ConvertedRecording:
    def __init__(self,directory,version,capacity,recorder_factory,*,exporter,fmt,title,suffix,phase_key):
        self.exporter=exporter;self.fmt=fmt;self.title=title;self.suffix=suffix;self.phase_key=phase_key
        self.original=recorder_factory(directory,version,capacity)
        self.lock=threading.RLock();self.worker=None;self.files=[];self.error='';self.phase='idle'
        self.directory=Path(directory)

    @property
    def busy(self):
        return self.original.busy or self.worker is not None and self.worker.is_alive()

    def start(self,nodes,endpoint,sample_ms,options):
        self.nodes=[dict(n) for n in nodes];self.options=dict(options or {})
        if self.options:self.options['parquet_profile']='compact'
        self.original.start('parquet',nodes,endpoint,sample_ms,self.options or None)
        self.phase='recording'
        self.worker=threading.Thread(target=self._run,name=self.title+'-Finalizer',daemon=False)
        try:self.worker.start()
        except Exception:
            self.original.stop('fda_start_error',10)
            raise
        return self.status()

    def enqueue(self,*args):return self.original.enqueue(*args)

    def stop(self,reason='user',timeout=5):
        start=time.monotonic();self.original.stop(reason,timeout)
        if self.worker is not None and self.worker is not threading.current_thread():
            self.worker.join(max(0,timeout-(time.monotonic()-start)))
        return self.status()

    def status(self):
        state=self.original.status()
        with self.lock:
            files=list(self.files);error=self.error;phase=self.phase
        active=self.original.busy
        busy=active or self.worker is not None and self.worker.is_alive()
        original=state['path'];filename=files[-1]['name'] if files else ''
        state.update(format=self.fmt,format_label=self.title+' + Parquet originali',
                     storage={'format':self.fmt,'label':self.title+' + Parquet originali','lossless':False,'original_archive_lossless':True},
                     original_files=state['files'],original_path=original,files=files,
                     filename=filename or Path(original).stem+self.suffix,
                     path=str(self.directory/filename) if filename else original,
                     state='recording' if state['state']=='recording' else 'stopping' if busy else 'error' if error or state['error'] else 'stopped',
                     busy=busy,active=state['state']=='recording',error=error or state['error'],conversion_phase=phase,
                     status_note='Archivio originale in acquisizione; i file '+self.title+' vengono generati dopo Stop.' if phase=='recording'
                     else 'Generazione '+self.title+' in corso; archivio originale gia salvato.' if phase=='converting'
                     else self.title+' generato; conservare anche archivio Parquet e metadati.' if phase=='ready' else '')
        state[self.phase_key]=phase
        return state

    def _run(self):
        try:
            self.original.worker.join()
            state=self.original.status()
            if state['state']=='error':
                raise ValueError('Acquisizione originale incompleta: '+state['error']+'; file parziale conservato, esportazione non generata')
            with self.lock:self.phase='converting'
            for part in state['files']:
                result=self.exporter(self.directory/part['name'],self.nodes,self.original.max_bytes)
                with self.lock:self.files.extend(result)
            with self.lock:self.phase='ready'
            logging.info('%s conversion completed: files=%d original_rows=%d',self.title,len(self.files),state['rows_written'])
        except Exception as exc:
            with self.lock:self.error='Errore generazione '+self.title+': '+str(exc)+'; archivio Parquet originale conservato';self.phase='error'
            logging.exception('%s conversion failure',self.title)
